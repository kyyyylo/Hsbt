import "./globals.css";

export const metadata = {
  title: "Housebets Contest Labs",
  description: "Discover creative challenges and win with Housebets Contest Labs."
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}