 "use client";

import { useEffect, useState } from "react";
import {
  Waves, Wallet, Crown, UserRound, House, Trophy, Menu, Search,
  MessageCircle, CircleDot, ArrowRight, X, Check, Sparkles, Clock3,
  ChevronDown, UploadCloud, Image as ImageIcon, FileText
} from "lucide-react";

const tabs = ["Akan Datang", "Dibuka", "Penilaian", "Hasil"];

export default function Home() {
  const [activeTab, setActiveTab] = useState("Dibuka");
  const [modalOpen, setModalOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [seconds, setSeconds] = useState(39);
  const [entryStarted, setEntryStarted] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setSeconds(s => s === 0 ? 59 : s - 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const statusCopy = {
    "Akan Datang": ["Segera hadir", "Tantangan ini belum dibuka. Bersiaplah untuk mengirimkan karya terbaikmu."],
    "Dibuka": ["Housebets Sportsbook is coming", "Design it. A clickable prototype: 5 pages, singles only."],
    "Penilaian": ["Karya sedang dinilai", "Tim kami sedang meninjau setiap entri. Hasil akan diumumkan setelah proses penilaian selesai."],
    "Hasil": ["Pemenang segera diumumkan", "Pantau halaman ini untuk melihat hasil akhir kompetisi."]
  };

  return (
    <main className="site-shell">
      <header className="topbar">
        <div className="topbar-inner">
          <button className="mobile-menu icon-btn" onClick={() => setMenuOpen(!menuOpen)} aria-label="Buka menu"><Menu /></button>
          <a className="brand" href="#" aria-label="Housebets home">
            <span className="brand-mark">H</span><Waves className="brand-wave" strokeWidth={1.7}/>
          </a>
          <div className="balance"><span className="coin">∞</span><strong>0.07721395</strong><ChevronDown size={17}/></div>
          <nav className={`top-actions ${menuOpen ? "show" : ""}`}>
            <button className="icon-btn wallet active" aria-label="Wallet"><Wallet /></button>
            <button className="icon-btn" aria-label="Rewards"><Crown /></button>
            <button className="icon-btn" aria-label="Profile"><UserRound /></button>
          </nav>
        </div>
      </header>

      <div className="page-wrap">
        <div className="breadcrumbs"><span>Housebets Contest Labs</span><ArrowRight size={15}/><strong>Design</strong></div>

        <section className="contest-card">
          <div className="contest-top">
            <div className="challenge-icon"><Sparkles size={27}/></div>
            <div className="contest-meta">
              <span className="eyebrow">DESIGN</span>
              <span className="muted">Berakhir dalam 3 minggu</span>
            </div>
            <span className="status"><i/> {activeTab}</span>
          </div>

          <div className="hero-copy">
            <p className="kicker">HOUSEBETS CONTEST LABS <span>·</span> CHALLENGE 001</p>
            <h1>{statusCopy[activeTab][0]}</h1>
            <p className="subtitle">{statusCopy[activeTab][1]}</p>
          </div>

          <div className="tabs" role="tablist" aria-label="Status kompetisi">
            {tabs.map(tab => (
              <button key={tab} role="tab" aria-selected={activeTab === tab}
                className={activeTab === tab ? "tab selected" : "tab"}
                onClick={() => setActiveTab(tab)}>{tab}</button>
            ))}
          </div>

          <div className="divider"/>
          <div className="prize-row">
            <div>
              <span className="section-label">HADIAH UTAMA</span>
              <div className="prize">US$15.000</div>
            </div>
            <div className="entries"><UserRound size={18}/><span>1 entri</span></div>
          </div>

          <div className="countdown-label">Berakhir dalam</div>
          <div className="countdown">
            <div className="time-box"><strong>22</strong><span>HARI</span></div>
            <div className="time-box"><strong>09</strong><span>JAM</span></div>
            <div className="time-box"><strong>{String(seconds).padStart(2, "0")}</strong><span>MNT</span></div>
          </div>

          <div className="autosave"><Check size={16}/> Sekitar 2 menit. Kami simpan otomatis.</div>
          <button className="primary-btn" onClick={() => setModalOpen(true)}>
            Mulai entrimu <ArrowRight size={19}/>
          </button>
          <p className="fineprint">Gratis untuk berpartisipasi <span>·</span> Satu entri per peserta</p>
        </section>

        <section className="below-grid">
          <article className="info-card">
            <div className="card-icon"><FileText size={19}/></div>
            <div><h3>Tentang tantangan</h3><p>Rancang pengalaman sportsbook Housebets yang segar, intuitif, dan mudah digunakan.</p></div>
          </article>
          <article className="info-card">
            <div className="card-icon"><Trophy size={19}/></div>
            <div><h3>Yang perlu dibuat</h3><p>Prototype interaktif dengan 5 halaman. Fokus pada pengalaman taruhan single.</p></div>
          </article>
        </section>
      </div>

      <nav className="bottom-nav">
        <a href="#"><Menu/><span>Menu</span></a>
        <a href="#"><CircleDot/><span>Olahraga</span></a>
        <a href="#"><Trophy/><span>Kontes</span></a>
        <a href="#"><MessageCircle/><span>Chat</span></a>
        <a href="#"><Search/><span>Cari</span></a>
      </nav>

      {modalOpen && (
        <div className="modal-backdrop" onClick={() => setModalOpen(false)}>
          <section className="entry-modal" onClick={e => e.stopPropagation()}>
            <button className="close-btn" onClick={() => setModalOpen(false)} aria-label="Tutup"><X/></button>
            {!entryStarted ? <>
              <div className="modal-symbol"><UploadCloud size={26}/></div>
              <span className="eyebrow">YOUR CREATIVE ENTRY</span>
              <h2>Mulai karyamu</h2>
              <p className="modal-copy">Buat prototype sportsbook Housebets dengan 5 halaman yang saling terhubung. Kamu bisa menyimpan progres dan melanjutkannya nanti.</p>
              <div className="brief-list">
                <div><Check/> 5 halaman interaktif</div>
                <div><Check/> Fokus pada single bets</div>
                <div><Check/> Simpan progres otomatis</div>
              </div>
              <button className="primary-btn modal-action" onClick={() => setEntryStarted(true)}>Buat entri sekarang <ArrowRight size={18}/></button>
            </> : <>
              <div className="modal-symbol success"><Check size={26}/></div>
              <span className="eyebrow">ENTRY WORKSPACE</span>
              <h2>Workspace siap!</h2>
              <p className="modal-copy">Ini adalah demo alur entri. Hubungkan autentikasi dan penyimpanan backend untuk menerima submission sungguhan.</p>
              <div className="workspace-placeholder"><ImageIcon/><span>Area upload desain / prototype</span></div>
              <button className="secondary-btn modal-action" onClick={() => { setEntryStarted(false); setModalOpen(false); }}>Selesai</button>
            </>}
          </section>
        </div>
      )}

      <footer className="footer"><span>HOUSEBETS <b>CONTEST LABS</b></span><span>Designed for the next generation.</span></footer>
    </main>
  );
}