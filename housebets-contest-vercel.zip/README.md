# Housebets Contest UI

Premium, responsive contest landing page built with Next.js.

## Run locally
1. Install Node.js 18.18+.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open `http://localhost:3000`.

## Deploy to Vercel
1. Upload this project to a GitHub repository.
2. Open https://vercel.com/new and import the repository.
3. Keep the default Next.js settings and click **Deploy**.

No environment variables are required for this front-end demo.

## Notes
- The countdown and tabs are demo interactions.
- The entry modal is a front-end prototype only. Real submissions require authentication, API routes, and persistent storage.
- Replace demo content and branding with assets you are authorized to use.
